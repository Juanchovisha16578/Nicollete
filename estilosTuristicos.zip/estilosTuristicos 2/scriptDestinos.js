const destinos = [
    'Passalacqua, Moltrasio, Italia',
    'Colline de France, Gramado, Brasil',
    'Belmond Copacabana Palace, Brasil',
    'Raffles, Dubái, Emiratos Árabes Unidos',
    'Hotel de Crillon, Paris, Francia' ,
    'Burj Al Arab, Dubái, Emiratos Árabes Unidos'

 ]

document.getElementById('button-random').addEventListener('click', function(){
    const randomText = Math.floor(Math.random() * destinos.length);
    document.getElementById('texto-random').textContent = destinos[randomText]
})