 const destinos = [
    'Machu Pichu, Lugar histórico en Peru',
    'Dubái, Emiratos Árabes Unidos',
    'Valle del cocoro, Colombia',
    'Hawai, Estado de EE. UU.',
    'Taj Mahal, India' ,
    'Bangkok, Tailandia'

 ]

document.getElementById('button-random').addEventListener('click', function(){
    const randomText = Math.floor(Math.random() * destinos.length);
    document.getElementById('texto-random').textContent = destinos[randomText]
})

/* Math.floor para redondear a numero entero*/