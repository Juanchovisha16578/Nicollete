//Arreglo que va a cargar los testimonios
const testimonios = [
    {nombre:"Juan David", comentario:"Una experiencia única, volveré pronto", lugar:"Bali, Indonesia" ,  imagen:"imgTestimonios/viajero10.jpeg"},
    {nombre: "Carlos", comentario: "Este es un lugar increíble para visitar.", lugar: "Machu Picchu, Perú", imagen:"imgTestimonios/viajero1-transformed.jpeg"},
    {nombre: "Ana", comentario: "Me encanta la cultura y la comida aquí.", lugar: "Kyoto, Japón", imagen:"imgTestimonios/viajero2.jpeg"},
    {nombre: "Luis", comentario: "El clima es perfecto todo el año.", lugar: "Honolulu, Hawái", imagen:"imgTestimonios/viajero3-transformed.png"},
    {nombre: "María", comentario: "Es un destino ideal para los amantes de la historia.", lugar: "Atenas, Grecia", imagen:"imgTestimonios/viajero4-transformed.png"},
    {nombre: "Sofía", comentario: "Los paisajes naturales son impresionantes.", lugar: "Banff, Canadá", imagen:"imgTestimonios/viajero5.jpeg"},
    {nombre: "Pedro", comentario: "Una ciudad llena de vida y cultura.", lugar: "Barcelona, España", imagen:"imgTestimonios/viajero6.jpeg"},
    {nombre: "Lucía",comentario: "La arquitectura aquí es increíble.", lugar: "Dubái, Emiratos Árabes Unidos", imagen:"imgTestimonios/viajero7.jpeg"},
    {nombre: "Mateo", comentario: "Un lugar perfecto para relajarse y disfrutar del mar.", lugar: "Maldivas", imagen:"imgTestimonios/viajero8.jpeg"},
    {nombre: "Elena", comentario: "Las auroras boreales aquí son mágicas.", lugar: "Reikiavik, Islandia", imagen:"imgTestimonios/viajero9.jpeg"}
];

//Acceder al contenedor 

const  testimonioContenedor = document.getElementById('testimonios-contenedor');

//For - hace la iteracion dependiendo de una condicion 
//For each - hace la iteracion de principio a fin sin preocuparse por los indices 

//Funcion  dinamica para generar los testimonios

function generarTestimonios(){
    //Crear un blucle para recorrer el arreglo 
    //La variable testimonio se lo que me  permite recorrer el arreglo
    testimonios.forEach(testimonio => {
        const testimonioDiv = document.createElement('div');
        testimonioDiv.classList.add('testimonio');
        //Crear imagen
        const imagen = document.createElement('img')
        imagen.src = testimonio.imagen; 
        imagen.alt = `Viajero ${testimonio.nombre}`;

        //Crear comentario
        const comentario  = document.createElement('p');
        comentario.textContent = `${testimonio.comentario} - ${testimonio.nombre}`;

        //Añadir imagen y comentario
        testimonioDiv.appendChild(imagen);
        testimonioDiv.appendChild(comentario);

        //Añadir lo que construimos al contenedor 
        testimonioContenedor.appendChild(testimonioDiv);
    });
}

window.onload = generarTestimonios;